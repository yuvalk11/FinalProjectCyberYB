package com.example.loginregister;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.*;
import java.io.*;

public class Client {
    private Socket clientSocket;
    private PrintWriter writer;
    private BufferedReader reader;

    public boolean startConnection(String ip, int port) {
        try {
            clientSocket = new Socket(ip, port);
            InputStream input = clientSocket.getInputStream();
            OutputStream output = clientSocket.getOutputStream();
            writer = new PrintWriter(output, true);
            reader = new BufferedReader(new InputStreamReader(input));
            return true;

        } catch (Exception e) {
            System.out.println("error 1 " + e.getMessage());
            return false;
        }
    }

    public String sendMessage(String msg) {
        String resp = "";
        try {
            int length = msg.length();
            String s = Integer.toString(length);
            String value = padLeftZeros(s, 4);
            String sendMessage = value + msg;
            writer.println(sendMessage);
            System.out.println("client: " + msg);
            resp = reader.readLine();

        } catch (Exception e) {
            System.out.println("error 2 " + e.getMessage());
        }
        return resp;
    }

    public void stopConnection() {
        try {

            reader.close();
            writer.close();
            clientSocket.close();
        } catch (Exception e) {
            System.out.println("error 3 " + e.getMessage());
        }
    }

    public String padLeftZeros(String inputString, int length) {
        if (inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length - inputString.length()) {
            sb.append('0');
        }
        sb.append(inputString);

        return sb.toString();
    }


    public static String[] convertArray(String resp) {
        String[] namesList = resp.split(",|#|\\(|\\)|\\s|\\'");
        int numElements = 0;
        for (int i = 0; i < namesList.length; i++) {
            namesList[i].trim();
            if (!namesList[i].isEmpty())
                numElements++;
            else
                namesList[i].trim();
        }
        String[] shortList = new String[numElements];
        int counter = 0;
        for (int j = 0; j < namesList.length; j++) {
            namesList[j].trim();
            if (!namesList[j].isEmpty()) {
                namesList[j].trim();
                shortList[counter] = namesList[j];
                shortList[counter].trim();
                counter++;
            }

        }
        return shortList;


    }
}