package com.example.loginregister;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.SQLException;
import java.util.ArrayList;

public class Results extends  AppCompatActivity {

    TableLayout tablelay;
    TableRow tablerow;
    TextView columeOrg, columnGroup, columnTotalSteps;
    TextView columeOrgHeader, columnGroupHeader, columnTotalStepsHeader;
    ArrayList<String> listofRowsCol1 = new ArrayList<String>();
    ArrayList<String> listofRowsCol2 = new ArrayList<String>();
    ArrayList<String> listofRowsCol3 = new ArrayList<String>();
    String resp;
    boolean successConnect;
    String queryUser;
    String [] array;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);
        tablelay = (TableLayout) findViewById(R.id.tablelayout1);
        tablelay.setColumnStretchable(0, true);
        tablelay.setColumnStretchable(1, true);
        tablelay.setColumnStretchable(2, true);
        columeOrgHeader = findViewById(R.id.rowHeaderCol1);
        columnGroupHeader = findViewById(R.id.rowHeaderCol2);
        columnTotalStepsHeader = findViewById(R.id.rowHeaderCol3);

        TextView resultTable;
        SharedPreferences preferences = getSharedPreferences("username", MODE_PRIVATE);
        String user = preferences.getString("userid", "");
        SharedPreferences pref = getSharedPreferences("Org", MODE_PRIVATE);
        String org = pref.getString("org", "");
        SharedPreferences pref2 = getSharedPreferences("Group", MODE_PRIVATE);
        String group = pref2.getString("group", "");
         queryUser = "select#select  OrgName, GroupName, TotalSteps from Groups where OrgName='"+group+"' order by 'TotalSteps' Desc";
        new Results.UpdateTask().execute();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if(successConnect){
                int countRow = 0;
                int num=0;
                for(int j=0; j<(array.length/3); j++) {
                    listofRowsCol1.add(array[num]);
                    listofRowsCol2.add(array[num+1]);
                    listofRowsCol3.add(array[num+2]);
                    countRow++;
                    num=num+3;
                }
                int i =0;
                while (i<countRow){
                    Toast.makeText(getApplicationContext(), listofRowsCol1.get(i)+ " "+listofRowsCol2.get(i) + " " +listofRowsCol3.get(i), Toast.LENGTH_SHORT).show();
                    columeOrg = new TextView(this);
                    columnGroup = new TextView(this);
                    columnTotalSteps = new TextView(this);
                    tablerow = new TableRow(this);
                    columeOrg.setText(listofRowsCol1.get(i));
                    //columeOrg.setText(rs.getString(1));
                    columeOrg.setTextSize(20);
                    columeOrg.setTextColor(Color.BLUE);
                    columeOrg.setGravity(Gravity.CENTER);
                    columnGroup.setText(listofRowsCol2.get(i));
                    //columnGroup.setText(rs.getString(2));
                    columnGroup.setTextSize(20);
                    columnGroup.setTextColor(Color.BLUE);
                    columnGroup.setGravity(Gravity.CENTER);
                    columnTotalSteps.setText(listofRowsCol3.get(i));
                    //columnTotalSteps.setText(rs.getString(3));
                    columnTotalSteps.setTextSize(20);
                    columnTotalSteps.setTextColor(Color.BLUE);
                    columnTotalSteps.setGravity(Gravity.CENTER);
                    //if (tablerow.getParent() != null){
                    //    ((ViewGroup)tablerow.getParent()).removeView(tablerow);
                    //}else {
                    if (i==0){
                        tablerow.setBackgroundColor(Color.YELLOW);
                    }
                        tablerow.addView(columeOrg);
                        tablerow.addView(columnGroup);
                        tablerow.addView(columnTotalSteps);
                        tablelay.addView(tablerow);
                    //}
                    //resultTable.setText(rs.getString(1));
                    i++;

                }

            }
         else  {
            Toast.makeText(getApplicationContext(), "cann't connect to Database", Toast.LENGTH_SHORT).show();
        }
    }
    private class UpdateTask extends AsyncTask<String, String,String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect = c.startConnection("192.168.1.45", 6969);
            String answer = c.sendMessage(queryUser);
            array = c.convertArray(answer);
            c.stopConnection();
            return resp;
        }
    }
    public void continueWindow(View v) throws SQLException {
        Intent intent = new Intent(getApplicationContext(), Excercise.class);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }
}
