package com.example.loginregister;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class SignUp extends AppCompatActivity {
    TextInputEditText textInputEditTextFullname, textInputEditTextPassword, textInputEditTextUsername, textInputEditTextID;
    Button buttonSignUp;
    TextView textViewLogin;
    ProgressBar progressBar;
    String resp;
    boolean successConnect;
    String queryUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        textInputEditTextUsername=findViewById(R.id.username);
        textInputEditTextID=findViewById(R.id.ID);
        textInputEditTextPassword=findViewById(R.id.password);
        textInputEditTextFullname=findViewById(R.id.fullname);
        buttonSignUp = findViewById(R.id.buttonSignUp);
        textViewLogin = findViewById(R.id.loginText);
        progressBar= findViewById(R.id.progress);

        textViewLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                finish();
            }
        });
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String fullname, username, password,email;
                fullname= String.valueOf(textInputEditTextFullname.getText());
                username= String.valueOf(textInputEditTextUsername.getText());
                password= String.valueOf(textInputEditTextPassword.getText());
                email = String.valueOf(textInputEditTextID.getText());

                if(!fullname.equals("") && !username.equals("") && !password.equals("")&&!email.equals("")) {
                    if (email.indexOf('@') != -1 && (email.indexOf('@')+1)!=(email.length())) {
                        progressBar.setVisibility(View.VISIBLE);
                        queryUser = "insert#INSERT INTO participants ( username, password, FullName, Email) VALUES ('" + username +
                                "','" + password + "','" + fullname + "','" + email + "');";
                        new SignUp.UpdateTask().execute();
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (successConnect) {
                            progressBar.setVisibility(View.GONE);
                            Intent intent = new Intent(getApplicationContext(), Login.class);
                            startActivity(intent);
                            finish();
                        } else
                            Toast.makeText(getApplicationContext(), "Check Connection", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Incorrect Email", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(), "All Fields Required", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
    private class UpdateTask extends AsyncTask<String, String,String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect= c.startConnection("192.168.1.45", 6969);
            c.sendMessage(queryUser);
            c.stopConnection();
            return resp;
        }

    }
}