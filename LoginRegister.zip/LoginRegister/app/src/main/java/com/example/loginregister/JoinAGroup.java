package com.example.loginregister;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class JoinAGroup extends AppCompatActivity {
    boolean initialTime = true;
    ArrayList<String> listofOrg = new ArrayList<String>();
    ArrayList<String> listofGroup = new ArrayList<String>();
    Spinner spinner1, spinner2;
    Button buttonSubmit;
    String queryUser;
    String resp;
    boolean successConnect;
    String[] array;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.joingroup);
        buttonSubmit = findViewById(R.id.buttonLoad);
        queryUser = "select#select distinct OrgName from Groups";
        listofOrg=updatingList(listofOrg);
        spinner1 = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_design, listofOrg);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), "you choose" + spinner1.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                listofGroup.clear();
                queryUser = "select#select GroupName from Groups where OrgName='" + spinner1.getSelectedItem().toString() + "';";
                listofGroup=updatingList(listofGroup);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        queryUser = "select#select GroupName from Groups where OrgName='" + spinner1.getSelectedItem().toString() + "';";
        listofGroup=updatingList(listofGroup);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, R.layout.spinner_design, listofGroup);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            SharedPreferences preferences = getSharedPreferences("username", MODE_PRIVATE);
            String user = preferences.getString("userid", "");

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (!initialTime) {
                    Toast.makeText(getApplicationContext(), "you choose" + spinner2.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                    //spinner2.setAdapter(null);
                    queryUser = "update#UPDATE participants SET OrgName='" + spinner1.getSelectedItem().toString() + "', GroupName='" + spinner2.getSelectedItem().toString() + "' where username='" + user + "';";
                    new JoinAGroup.UpdateTask().execute();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if (successConnect) {
                        Toast.makeText(getApplicationContext(), "Thank you" + user + " for Joining new team", Toast.LENGTH_SHORT).show();
                        SharedPreferences preferences = getSharedPreferences("Org", MODE_PRIVATE);
                        SharedPreferences preferences2 = getSharedPreferences("Group", MODE_PRIVATE);
                        SharedPreferences.Editor editor1 = preferences.edit();
                        SharedPreferences.Editor editor2 = preferences2.edit();
                        editor1.putString("org", spinner2.getSelectedItem().toString());
                        editor2.putString("group", spinner1.getSelectedItem().toString());
                        editor1.apply();
                        editor2.apply();
                    } else{
                        Toast.makeText(getApplicationContext(), "can't connect to Database", Toast.LENGTH_SHORT).show();
                    }
                } else
                    initialTime = false;
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public void clickToSubmit(View v) {
        Intent intent = new Intent(getApplicationContext(), Excercise.class);
        startActivity(intent);
    }

    private class UpdateTask extends AsyncTask<String, String, String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect = c.startConnection("192.168.1.45", 6969);
            String answer = c.sendMessage(queryUser);
            array = c.convertArray(answer);
            c.stopConnection();
            return resp;
        }
    }

    public ArrayList updatingList(ArrayList l) {
        new JoinAGroup.UpdateTask().execute();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (successConnect) {
            l.add("-----------");
            int lengthGroupArray = array.length;
            for (int j = 0; j < lengthGroupArray; j++) {
                l.add(array[j]);
            }

        } else {
            Toast.makeText(getApplicationContext(), "cannt connect to Database", Toast.LENGTH_SHORT).show();
        }
        return l;
    }


}

