package com.example.loginregister;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    boolean alreadyAssignedToGroup = false;
    String resp;
    boolean successConnect;
    String queryUser;
    String [] array;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences preferences = getSharedPreferences("username", MODE_PRIVATE);
        String user = preferences.getString("userid","");
        TextView helloUser = (TextView) findViewById(R.id.text1);
        //SharedPreferences pref = getSharedPreferences("Org", MODE_PRIVATE);
        //SharedPreferences pref2 = getSharedPreferences("Group", MODE_PRIVATE);
        //String org = pref.getString("org","");
        //String group = pref2.getString("group","");

        queryUser = "select#Select OrgName,GroupName from participants where username='" + user + "';";
        new MainActivity.UpdateTask().execute();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if(successConnect){
            String field = array[0];
            if (field != null )
                alreadyAssignedToGroup = true;
            //}
        } else
            Toast.makeText(this, "Not connection to Database", Toast.LENGTH_SHORT).show();

        String org =array[0];
        String group =array[1];

        if (alreadyAssignedToGroup){
            helloUser.setText(Html.fromHtml("<b>Hello "+ user + "</b><br>Welcome to stepAhead game<br>You are assigned to:<br>Organization: <b><font color='blue'>"+ group +"</font></b><br>Group:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp<b><font color='blue'>"+ org+"</font></b><br><br>To start Activity click menu" ));
        }else{
            helloUser.setText("Hello "+ user + "Welcome to stepAhead game\nYou are not assigned currently to any Organizations or Groups\nPlease join a group using the MENU");
        }


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch(item.getItemId()){
            case R.id.JoinGroup:
                Toast.makeText(this, "Click to join group", Toast.LENGTH_SHORT).show();
                intent = new Intent(getApplicationContext(), JoinAGroup.class);
                startActivity(intent);
                break;
            case R.id.goexcercise:
                if (alreadyAssignedToGroup) {
                    intent = new Intent(getApplicationContext(), Excercise.class);
                    startActivity(intent);
                } else
                    Toast.makeText(this, "You need to join a group first", Toast.LENGTH_SHORT).show();
                break;
            case R.id.checkresult:
                Toast.makeText(this, "checkresult", Toast.LENGTH_SHORT).show();
                intent = new Intent(getApplicationContext(), Results.class);
                startActivity(intent);
                return true;
            case R.id.CreateGroup:
                intent = new Intent(getApplicationContext(), CreateOrgAndGroup.class);
                startActivity(intent);
                return true;
            case R.id.Logout:
                Toast.makeText(this, "Login", Toast.LENGTH_SHORT).show();
                SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("remember", "false");
                editor.apply();
                editor.commit();
                finish();
                intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }
    private class UpdateTask extends AsyncTask<String, String,String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect = c.startConnection("192.168.1.45", 6969);
            String answer = c.sendMessage(queryUser);
            array = c.convertArray(answer);
            c.stopConnection();
            return resp;
        }
    }

}