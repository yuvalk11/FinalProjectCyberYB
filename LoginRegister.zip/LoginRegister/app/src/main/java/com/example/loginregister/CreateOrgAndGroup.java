package com.example.loginregister;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateOrgAndGroup extends AppCompatActivity {
    EditText organization, groupName;
    Button buttonAdd;
    Button buttonFinish;
    String resp;
    boolean successConnect;
    String queryUser;




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.creategroupform);
        organization=findViewById(R.id.textOrg);
        groupName=findViewById(R.id.textGroupName);
        buttonAdd = findViewById(R.id.add);
        buttonFinish = findViewById(R.id.finish);




    }
    public void addOrg(View v) {

        boolean found = (organization.getText().toString().contains(" ")||(groupName.getText().toString().contains(" ")));
        boolean found2 = (organization.getText().toString().contains("#")||(groupName.getText().toString().contains("#")));
        if(!(found)&&!(found2)) {
            queryUser = "insert#Insert into Groups ( OrgName, GroupName, TotalSteps, AvgTotalSteps) VALUES ('" + organization.getText() + "','" + groupName.getText() + "','" + 0 + "','" + 0 + "');";
            new CreateOrgAndGroup.UpdateTask().execute();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (successConnect) {
            } else {
                Toast.makeText(getApplicationContext(), "cannt connect to Database", Toast.LENGTH_SHORT).show();
            }
            groupName.setText("");
        }
        else{
            Toast.makeText(getApplicationContext(), "Do not use space or '#'. Please write '-' ", Toast.LENGTH_LONG).show();
        }

    }
    public void finishMethod(View v) throws SQLException {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
    private class UpdateTask extends AsyncTask<String, String, String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect = c.startConnection("192.168.1.45", 6969);
            c.sendMessage(queryUser);
            c.stopConnection();
            return resp;
        }
    }
}
