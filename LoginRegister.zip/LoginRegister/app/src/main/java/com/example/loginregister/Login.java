package com.example.loginregister;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Login extends AppCompatActivity {
    TextInputEditText  textInputEditTextPassword, textInputEditTextUsername;
    Button buttonLogin;
    TextView textViewSignUp;
    ProgressBar progressBar;
    CheckBox remember ;
    String username, password;
    String resp;
    boolean successConnect;
    String queryUser;
    String [] array;
    CheckBox showPass;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        textInputEditTextUsername=findViewById(R.id.username);
        textInputEditTextPassword=findViewById(R.id.password);
        showPass=findViewById(R.id.showPassword);
        showPass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {
                    textInputEditTextPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{
                   textInputEditTextPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());;
                }
            }
        });
        textInputEditTextPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewSignUp = findViewById(R.id.signUpText);
        progressBar=findViewById(R.id.progress);
        remember = findViewById(R.id.rememberMeCheck);
        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
        String checkbox = preferences.getString("remember","");
        if (checkbox.equals("true")){
            finish();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);

        }else {
            textViewSignUp.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    finish();
                    Intent intent = new Intent(getApplicationContext(), SignUp.class);
                    startActivity(intent);

                }
            });

            buttonLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    username = String.valueOf(textInputEditTextUsername.getText());
                    password = String.valueOf(textInputEditTextPassword.getText());
                    if (!username.equals("") && !password.equals("")) {
                        progressBar.setVisibility(View.VISIBLE);

                            queryUser = "select#select username,password from participants where username='" + username + "';";
                            new Login.UpdateTask().execute();
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if (successConnect&&array.length!=0) {
                                if (array[0].trim().equalsIgnoreCase(username) && array[1].trim().equalsIgnoreCase(password)) {
                                    //Toast.makeText(getApplicationContext(), "Access allowd for" + queryUser, Toast.LENGTH_SHORT).show();
                                    //connect.close();
                                    SharedPreferences preferences2 = getSharedPreferences("username", MODE_PRIVATE);
                                    SharedPreferences.Editor editor2 = preferences2.edit();
                                    editor2 = preferences2.edit();
                                    editor2.putString("userid",username );
                                    editor2.apply();
                                    if (remember.isChecked()) {
                                        SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                                        SharedPreferences.Editor editor = preferences.edit();
                                        editor = preferences.edit();
                                        editor.putString("remember", "true");
                                        editor.apply();

                                    } else if (!remember.isChecked()) {
                                        SharedPreferences preferences = getSharedPreferences(" checkbox", MODE_PRIVATE);
                                        SharedPreferences.Editor editor = preferences.edit();
                                        editor.putString("remember", "false");
                                        editor = preferences.edit();
                                        editor.apply();
                                    }
                                    finish();
                                    progressBar.setVisibility(View.GONE);
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent);
                                } else
                                    Toast.makeText(getApplicationContext(), "You are not registered ot wrong input", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);
                            } else
                                Toast.makeText(getApplicationContext(), "check Connection or user is not registered", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);
                    } else
                        Toast.makeText(getApplicationContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                }

            });
        }
    }

    private class UpdateTask extends AsyncTask<String, String,String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect= c.startConnection("192.168.1.45", 6969);
            String answer = c.sendMessage(queryUser);
            array = c.convertArray(answer);
            c.stopConnection();
            return resp;
        }

    }


}