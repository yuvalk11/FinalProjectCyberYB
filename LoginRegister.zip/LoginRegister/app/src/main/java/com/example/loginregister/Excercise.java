package com.example.loginregister;
import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Excercise extends AppCompatActivity implements SensorEventListener{

        private TextView textViewStepCounter, textViewStepDetector;
        private SensorManager sensorManager;
        private Sensor mStepCounter;
        private boolean isCounterSensorPresent;
        int stepCount=0;
        Button buttonLoad, exitButton;
        TextView dialyStepsview ;
        String resp;
        boolean successConnect;
        String queryUser;
        String [] array;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            SharedPreferences preferences = getSharedPreferences("username", MODE_PRIVATE);
            String user = preferences.getString("userid","");
            SharedPreferences pref = getSharedPreferences("Org", MODE_PRIVATE);
            String org = pref.getString("org", "");
            SharedPreferences pref2 = getSharedPreferences("Group", MODE_PRIVATE);
            String group = pref2.getString("group", "");

            String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
            String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
            super.onCreate(savedInstanceState);
            buttonLoad = findViewById(R.id.buttonLoad);
            exitButton = findViewById(R.id.exitButton);

            setContentView(R.layout.excercise);
            if(ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_DENIED){ //ask for permission
                requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 0);
            }
            buttonLoad = findViewById(R.id.buttonLoad);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            textViewStepCounter = findViewById(R.id.stepscount);
            //textViewStepDetector = findViewById(R.id.textVievStepDetector);
            sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null){
                mStepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
                isCounterSensorPresent = true;
            }else{
                textViewStepCounter.setText("Counter Sensor is not present");
                isCounterSensorPresent = false;
            }
            dialyStepsview = findViewById(R.id.dailyStepview);
            queryUser = "select#select SUM(dailySteps) from StepsUpload where username='"+user+ "' and time ='" + currentDate + "';";
            doExcerise();
            if(successConnect){
                String steps = array[0];
                Toast.makeText(getApplicationContext(), "totalstepdaily" +steps  , Toast.LENGTH_SHORT).show();
                dialyStepsview.setText(steps);
            }else {
                Toast.makeText(getApplicationContext(), "cann't connect to Database", Toast.LENGTH_SHORT).show();
            }
            buttonLoad.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(View v) {

                            queryUser = "insert#INSERT INTO StepsUpload ( username, date, time, dailySteps) VALUES ('" + user + "','" + currentTime + "','" + currentDate + "','" + stepCount + "');";
                    doExcerise();
                    if(successConnect){
                            int tempStepCount=0;
                            tempStepCount = stepCount;
                            stepCount = 0;
                            textViewStepCounter.setText(String.valueOf(stepCount));
                            queryUser = "select#select TotalSteps from Groups where OrgName='"+ group +"' and GroupName='"+ org + "';";
                        doExcerise();
                            int tempInt = Integer.parseInt(array[0]);
                            int steptoLoadtoGroup = 0;
                                steptoLoadtoGroup = tempStepCount + tempInt;
                                queryUser = "update#UPDATE Groups SET TotalSteps='"+ steptoLoadtoGroup +"' where OrgName='"+ group +"' and GroupName='"+ org + "';";
                        doExcerise();
                             queryUser= "select#select sum(dailySteps) from StepsUpload where username ='" + user + "' and time ='" + currentDate + "';";
                        new Excercise.UpdateTask().execute();
                        try {
                            Thread.sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                            int updateNewdailySteps = Integer.parseInt(array[0]) ;
                            dialyStepsview.setText(String.valueOf(updateNewdailySteps));

                    }else {
                        Toast.makeText(getApplicationContext(), "cannt connect to Database" , Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if ( sensorEvent.sensor.getType() == mStepCounter.getType()) {
                stepCount++;
                textViewStepCounter.setText(String.valueOf(stepCount));
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }

    @Override
            public void onResume() {
                super.onResume();
                if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null)
                    sensorManager.registerListener(this, mStepCounter, SensorManager.SENSOR_DELAY_NORMAL);
            }
            @Override
            public void onPause(){
                super.onPause();
                if (sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null)
                    sensorManager.unregisterListener(this, mStepCounter);
            }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch(item.getItemId()){
            case R.id.checkresult:
                Toast.makeText(this, "checkresult", Toast.LENGTH_SHORT).show();
                intent = new Intent(getApplicationContext(), Results.class);
                startActivity(intent);
                return true;
            case R.id.About:
                Toast.makeText(this, "This Application was written By Yuval Kleinman", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.Logout:
                Toast.makeText(this, "Login", Toast.LENGTH_SHORT).show();
                SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("remember", "false");
                editor.apply();
                editor.commit();
                finish();
                intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.resultmenu,menu);
        return true;
    }

    public void myFancyMethod(View v) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
    private class UpdateTask extends AsyncTask<String, String,String> {
        protected String doInBackground(String... urls) {
            Client c = new Client();
            successConnect = c.startConnection("192.168.1.45", 6969);
            String answer = c.sendMessage(queryUser);
            array = c.convertArray(answer);
            c.stopConnection();
            return resp;
        }
    }
    public void doExcerise(){
        new Excercise.UpdateTask().execute();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}




